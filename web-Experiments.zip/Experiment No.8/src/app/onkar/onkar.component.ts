import { Component } from '@angular/core';

@Component({
  selector: 'app-onkar',
  templateUrl: './onkar.component.html',
  styleUrls: ['./onkar.component.css']
})
export class OnkarComponent {

}

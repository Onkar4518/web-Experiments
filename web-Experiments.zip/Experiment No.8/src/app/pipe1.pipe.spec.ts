import { Pipe1Pipe } from './pipe1.pipe';

describe('Pipe1Pipe', () => {
  it('create an instance', () => {
    const pipe = new Pipe1Pipe();
    expect(pipe).toBeTruthy();
  });
});
